import geemap
geemap.update_package()