import tkinter as tk
import pandas as pd
from PIL import Image, ImageTk

# Function to classify the flower based on input values
def classify_flower():
    androecium = int(and_entry.get())
    gynoecium = int(gyn_entry.get())
    sepals = int(stigma_entry.get())
    petals = int(style_entry.get())
    color = color_entry.get().lower()

    # Load flower data from CSV
    flower_data = pd.read_csv('flower_dataset.csv')

    # Filter data based on input criteria
    filtered_data = flower_data[
        (flower_data['Androecium'] == androecium) &
        (flower_data['Gynoecium'] == gynoecium) &
        (flower_data['Sepal'] == sepals) &
        (flower_data['Petal'] == petals) &
        (flower_data['Color'].str.lower() == color)
    ]

    if not filtered_data.empty:
        flower_name = filtered_data.iloc[0]['Flower']
        scientific_name = filtered_data.iloc[0]['Scientific']
        image_path = f"{flower_name.lower()}.jpg"  # Assuming images are named as flowername.png

        # Load the image and display it as is
        try:
            img = Image.open(image_path)
            img = ImageTk.PhotoImage(img)
            img_label.config(image=img)
            img_label.image = img
        except Exception as e:
            img_label.config(image="")
            print("Error loading image:", str(e))

        name_label.config(text=f"Flower Name: {flower_name}")
        sci_label.config(text=f"Scientific Name: {scientific_name}")
    else:
        name_label.config(text="Flower not found")
        sci_label.config(text="")
        img_label.config(image="")

# Create the main window
window = tk.Tk()
window.title("Flower Classifier")
window.geometry("1366x768")  # Set the window size to 1366x768

# Set the background image
bg_image = Image.open('images//Floran.png')
bg_photo = ImageTk.PhotoImage(bg_image)
bg_label = tk.Label(window, image=bg_photo)
bg_label.place(x=0, y=0, relwidth=1, relheight=1)

# Create and place input fields and labels with specified font and colors
font_style = ('Times New Roman', 25, 'bold')
fg_color = 'black'
bg_color = 'white'

lbl_stigma = tk.Label(window, text="Stigma:", font=font_style, fg=fg_color, bg=bg_color)
stigma_entry = tk.Entry(window, font=font_style, width=5, bd=10, fg='black', bg='white')
lbl_style = tk.Label(window, text="Style:", font=font_style, fg=fg_color, bg=bg_color)
style_entry = tk.Entry(window, font=font_style, width=5, bd=10, fg='black', bg='white')
lbl_and = tk.Label(window, text="Androecium:", font=font_style, fg=fg_color, bg=bg_color)
and_entry = tk.Entry(window, font=font_style, width=5, bd=10, fg='black', bg='white')
lbl_gyn = tk.Label(window, text="Gynoecium:", font=font_style, fg=fg_color, bg=bg_color)
gyn_entry = tk.Entry(window, font=font_style, width=5, bd=10, fg='black', bg='white')
lbl_color = tk.Label(window, text="Color:", font=font_style, fg=fg_color, bg=bg_color)
color_entry = tk.Entry(window, font=font_style, width=5, bd=10, fg='black', bg='white')


lbl_stigma.place(x=100, y=150)
stigma_entry.place(x=350, y=150)
lbl_style.place(x=100, y=250)
style_entry.place(x=350, y=250)
lbl_and.place(x=100, y=350)
and_entry.place(x=350, y=350)
lbl_gyn.place(x=100, y=450)
gyn_entry.place(x=350, y=450)
lbl_color.place(x=100, y=550)
color_entry.place(x=350, y=550)

# Create and place the classify button with specified font and colors
classify_button = tk.Button(window, text="Classify Flower", command=classify_flower, font=font_style, fg=fg_color, bg=bg_color)
classify_button.place(x=300, y=650)

# Create and place the labels for flower name, scientific name, and image with specified font and colors
name_label = tk.Label(window, text="", font=font_style, fg=fg_color, bg=bg_color)
name_label.place(x=750, y=570)
sci_label = tk.Label(window, text="", font=font_style, fg=fg_color, bg=bg_color)
sci_label.place(x=750, y=620)
img_label = tk.Label(window)
img_label.place(x=720, y=90) 

# Run the application
window.mainloop()
