import tkinter as tk
from tkinter import ttk
import matplotlib.pyplot as plt
import pandas as pd

def plot_migration_data():
    bird_name = bird_name_entry.get()
    bird_data = data[data['Bird Name'] == bird_name]
    
    if not bird_data.empty:
        years_before = bird_data['Years Before']
        total_migrated = bird_data['Total Migrated']
        distance_travelled = bird_data['Distance Travelled']

        # Plotting data
        plt.figure(figsize=(15, 4))
        
        plt.subplot(131)
        plt.plot(years_before, total_migrated)
        plt.title('Total Migrated vs Years Before')
        plt.xlabel('Years Before')
        plt.ylabel('Total Migrated')

        plt.subplot(132)
        plt.plot(years_before, total_migrated)
        plt.title('Total Migrated vs Years Before')
        plt.xlabel('Years Before')
        plt.ylabel('Total Migrated')

        plt.subplot(133)
        plt.plot(years_before, distance_travelled)
        plt.title('Distance Travelled vs Years Before')
        plt.xlabel('Years Before')
        plt.ylabel('Distance Travelled')

        plt.tight_layout()
        plt.show()
    else:
        result_label.config(text="Bird not found")

# Create the main window
root = tk.Tk()
root.geometry("1366x768")
root.title("Migration_Page")

# Set a background image
bg_image = tk.PhotoImage(file='images//Migration.png')
bg_label = tk.Label(root, image=bg_image)
bg_label.place(relwidth=1, relheight=1)

# Load the dataset from a CSV file
data = pd.read_csv("bird_migration_data.csv")

# Bird name input
bird_name_label = ttk.Label(root, text="Enter Bird Name:")
bird_name_label.place(x=300, y=150)

bird_name_entry = ttk.Entry(root)
bird_name_entry.place(x=400, y=150)

# Plot button
plot_button = ttk.Button(root, text="OK", command=plot_migration_data)
plot_button.place(x=500, y=150)

# Result label
result_label = ttk.Label(root, text="")
result_label.place(x=300, y=200)

# Position the graphs
graph_width = 400
graph_height = 400
graph_x = 100

# Create a placeholder label for graph spacing
graph_spacing = ttk.Label(root, text="")
graph_spacing.place(x=0, y=300)

# Function to position and display graphs
def position_graphs():
    for i in range(3):
        plt.figure(figsize=(5, 5))
        plt.subplot(111)
        plt.plot([1, 2, 3, 4, 5], [1, 2, 3, 4, 5])  # Replace with actual data
        plt.title('Graph ' + str(i + 1))
        plt.xlabel('X-axis')
        plt.ylabel('Y-axis')
        
        plt.savefig(f'graph_{i + 1}.png', bbox_inches='tight')
        
        graph_label = tk.Label(root, image=tk.PhotoImage(file=f'graph_{i + 1}.png'))
        graph_label.image = tk.PhotoImage(file=f'graph_{i + 1}.png')
        graph_label.place(x=graph_x, y=300)
        
        graph_x += graph_width + 100

position_graphs()

# Start the GUI event loop
root.mainloop()