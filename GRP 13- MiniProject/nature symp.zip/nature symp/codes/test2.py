from tkinter import *
import tkinter as tk
import pandas as pd
from tkinter import messagebox
from PIL import ImageTk,Image
import os


# ---------------------------------------------------- GUI ----------------------------------------------------

# Create the Tkinter window and run the application
Floran_Page = Tk()
Floran_Page.title("Floran_Page")
Floran_Page.geometry('1366x768')
Floran_Page.iconbitmap('')
Floran_Page.resizable(False, False)

cd_bg_image = ImageTk.PhotoImage(file='images//Floran.png')
cd_bg_label = Label(Floran_Page, image=cd_bg_image)
cd_bg_label.place(x=0, y=0)

def Germinate():
    Floran_Page.destroy()
    import Germination  

def classify():
    androecium = int(and_entry.get())
    gynoecium = int(gyn_entry.get())
    sepals = int(stigma_entry.get())
    petals = int(style_entry.get())
    color = color_entry.get().lower()

    # Read the dataset from Flower_Table.csv
    try:
        flower_data = pd.read_csv('flower_dataset.csv')
    except FileNotFoundError:
        result_label.config(text="Dataset not found")
        return

    # Filter the dataset based on the input values
    filtered_data = flower_data[
        (flower_data['Androecium'] == androecium) &
        (flower_data['Gynoecium'] == gynoecium) &
        (flower_data['Sepal'] == sepals) &
        (flower_data['Petal'] == petals) &
        (flower_data['Color'].str.lower() == color)
    ]

    if not filtered_data.empty:
        flower_name = filtered_data.iloc[0]['Flower']
        scientific_name = filtered_data.iloc[0]['Scientific']
        # result_label.config(text=f"Flower Name: {flower_name}")
        # sci_label.config(text=f"Scientific Name: {scientific_name}")

        # image_path = f"{flower_name.lower()}.jpg"
        # img = Image.open(image_path)
        # img = img.resize((130,130),Image.ANTIALIAS)
        # img = ImageTk.PhotoImage(img)
        # image_label.config(image=img)
        image_name = f"{flower_name.lower()}.jpg"
        image_path = os.path.join('flower_image',image_name)

        if os.path.exists(image_path):
            img = Image.open(image_path)
            # img = img.resize((500,500), Image.ANTIALIAS)
            img = img.resize((130,130), Image.Resampling.LANCZOS)
            img = ImageTk.PhotoImage(img)
            image_label.config(image=img)
            result_label.config(text=f"Flower Name: {flower_name}")
            sci_label.config(text=f"Scientific Name: {scientific_name}")

        else:
            result_label.config(text="No matching flower found")
            image_label.config(image="")
            sci_label.config(image="")

    else:
        result_label.config(text="No matching flower found")
        image_label.config(image="")
        sci_label.config(image="")
        

head_lbl = Label(Floran_Page, text='Enter Flower Details ', font=('Times New Roman', 35, 'bold'),
                    fg='black',bg='white')
head_lbl.place(x=330, y=50)

lbl_stigma = Label(Floran_Page, text='No. of stigma', font=('Times New Roman', 25, 'bold'),
                    fg='black',bg='white')
lbl_stigma.place(x=100, y=150)

stigma_entry = Entry(Floran_Page, width=5,border=10, font=('Times New Roman', 25), bd=0, fg='black', bg='white')
stigma_entry.place(x=400, y=150)

lbl_style = Label(Floran_Page, text='No. of style', font=('Times New Roman', 25, 'bold'),
                    fg='black',bg='white')
lbl_style.place(x=100, y=250)

style_entry = Entry(Floran_Page, width=5,border=10, font=('Times New Roman', 25), bd=0, fg='black', bg='white')
style_entry.place(x=400, y=250)

lbl_and = Label(Floran_Page, text='No. of androecium', font=('Times New Roman', 25, 'bold'),
                    fg='black',bg='white')
lbl_and.place(x=100, y=350)

and_entry = Entry(Floran_Page, width=5,border=10, font=('Times New Roman', 25), bd=0, fg='black', bg='white')
and_entry.place(x=400, y=350)

lbl_gyn = Label(Floran_Page, text='No. of gynoecium', font=('Times New Roman', 25, 'bold'),
                    fg='black',bg='white')
lbl_gyn.place(x=100, y=450)

gyn_entry = Entry(Floran_Page, width=5,border=10, font=('Times New Roman', 25), bd=0, fg='black', bg='white')
gyn_entry.place(x=400, y=450)

lbl_color = Label(Floran_Page, text=' Color', font=('Times New Roman', 25, 'bold'),
                    fg='black',bg='white')
lbl_color.place(x=100, y=550)

color_entry = Entry(Floran_Page, width=5,border= 10, font=('Times New Roman', 25), bd=0, fg='black', bg='white')
color_entry.place(x=400, y=550)

Button(Floran_Page, text='Classify', font=('Open Sans', 20, 'bold'), fg='black', bg='gray', cursor='hand2',
        bd=0, width=20, height=1, command=classify).place(x=300,y=650)

Button(Floran_Page, text='Germination', font=('Open Sans', 20, 'bold'), fg='black', bg='white', cursor='hand2',
        bd=0, width=10, height=1, command= Germinate).place(x=1170,y=60)

image_label = Label(Floran_Page, text='')
image_label.place(x=900, y=150)

result_label = Label(Floran_Page, text="", font=('Times New Roman', 25, 'bold'),
                    fg='black',bg='white')
result_label.place(x=900, y=400)

sci_label = Label(Floran_Page, text='', font=('Times New Roman', 25, 'bold'),
                    fg='black',bg='white')
sci_label.place(x=900, y=500)

Floran_Page.mainloop()