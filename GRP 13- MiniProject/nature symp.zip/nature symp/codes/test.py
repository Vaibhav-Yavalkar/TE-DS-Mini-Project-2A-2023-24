import tkinter as tk
from tkinter import messagebox
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import pandas as pd

# Function to create the growth graph and count of flowers graph
def create_growth_graph():
    plant_name = plant_name_entry.get()
    flower_data = df[df['Flower'] == plant_name]

    if flower_data.empty:
        messagebox.showerror("Error", "Flower data not found.")
        return

    days = flower_data['Day']
    height = flower_data['Height']

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 4))
    ax1.plot(days, height, marker='o')
    ax1.set_xlabel('Days')
    ax1.set_ylabel('Height')
    ax1.set_title(f'Growth of {plant_name}')

    # Calculate the data for 'Day' vs 'Bud' for the selected flower
    day_vs_bud_data = flower_data[['Day', 'Bud']]
    ax2.plot(day_vs_bud_data['Day'], day_vs_bud_data['Bud'], marker='o', color='green')
    ax2.set_xlabel('Days')
    ax2.set_ylabel('Bud')
    ax2.set_title(f'Day vs Bud for {plant_name}')

    canvas = FigureCanvasTkAgg(fig, master=window)
    canvas_widget = canvas.get_tk_widget()
    canvas_widget.grid(row=4, columnspan=2, padx=10, pady=10)

# Read the dataset from growth.csv
df = pd.read_csv("plant_growth.csv")

# Create the main window
window = tk.Tk()
window.title("Plant Growth Comparison")
window.geometry("1366x768")  # Set the window size

# Load and display the background image
bg_image = tk.PhotoImage(file="images/Germination.png")
bg_label = tk.Label(window, image=bg_image)
bg_label.place(relwidth=1, relheight=1)

# Label and Entry for plant name
plant_name_label = tk.Label(window, text="Enter Flower Name:", font=('Open Sans', 20, 'bold'), fg='black')
plant_name_label.place(x=400, y=550)
plant_name_entry = tk.Entry(window, font=('Open Sans', 20, 'bold'), fg='black', bd=0)
plant_name_entry.place(x=700, y=550)
ok_button = tk.Button(window, text="OK", command=create_growth_graph, font=('Open Sans', 20, 'bold'), 
                      fg='black', bg='gray', cursor='hand2', bd=0, width=20, height=1)
ok_button.place(x=500, y=590)

# Run the Tkinter main loop
window.mainloop()
