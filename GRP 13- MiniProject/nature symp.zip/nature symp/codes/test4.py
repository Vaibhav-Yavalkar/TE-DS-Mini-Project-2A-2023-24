import pandas as pd
import tkinter as tk
from tkinter import ttk
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

# Load the dataset
plant_growth = pd.read_csv('plant_growth.csv', delimiter='\t')
# plant_growth = pd.read_csv('flower_dataset.csv', delimiter='\t')
# Function to create and display graphs
def create_growth_graph():
    plant_name = plant_name_entry.get()
    
    if plant_name not in plant_growth['Flower'].unique():
        result_label.config(text=f"Flower '{plant_name}' not found in the dataset.")
        return
    
    flower_data = plant_growth[plant_growth['Flower'] == plant_name]
    
    # Plot growth time
    fig1 = plt.figure(1, figsize=(400, 400))
    plt.plot(flower_data['Day'], flower_data['Height (cm)'])
    plt.title(f'Plant Growth Over Time for {plant_name}')
    plt.xlabel('Day')
    plt.ylabel('Height (cm)')
    
    # Plot growth season
    fig2 = plt.figure(2, figsize=(400, 400))
    plt.bar(flower_data['Season'], flower_data['Height (cm)'])
    plt.title(f'Plant Growth by Season for {plant_name}')
    plt.xlabel('Season')
    plt.ylabel('Height (cm)')
    
    # Plot plant life
    fig3 = plt.figure(3, figsize=(400, 400))
    plt.plot(flower_data['Day'], flower_data['Number of Leaves'], label='Number of Leaves')
    plt.plot(flower_data['Day'], flower_data['Flower Buds'], label='Flower Buds')
    plt.title(f'Plant Life for {plant_name}')
    plt.xlabel('Day')
    plt.ylabel('Count')
    plt.legend()

    canvas1 = FigureCanvasTkAgg(fig1, master=root)
    canvas1.get_tk_widget().place(x=100, y=250)
    
    canvas2 = FigureCanvasTkAgg(fig2, master=root)
    canvas2.get_tk_widget().place(x=500, y=250)
    
    canvas3 = FigureCanvasTkAgg(fig3, master=root)
    canvas3.get_tk_widget().place(x=900, y=250)

# Create the GUI
root = tk.Tk()
root.title('Germination_Page')
root.geometry('1366x768')

# Set background image
bg_image = tk.PhotoImage(file='images//Germination.png')
bg_label = tk.Label(root, image=bg_image)
bg_label.place(x=0, y=0, relwidth=1, relheight=1)

# Create a label and entry for entering the plant name
label = ttk.Label(root, text='Enter Plant Name:')
label.place(x=300, y=150)

plant_name_entry = ttk.Entry(root)
plant_name_entry.place(x=450, y=150)

# Create a button to generate the graphs
estimate_button = ttk.Button(root, text='Estimate', command=create_growth_graph)
estimate_button.place(x=600, y=150)

# Create a label for displaying results or errors
result_label = ttk.Label(root, text='')
result_label.place(x=600, y=200)

root.mainloop()