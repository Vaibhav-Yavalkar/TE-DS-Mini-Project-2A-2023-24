from tkinter import *
from tkinter import messagebox
from PIL import ImageTk
import subprocess


# ---------------------------------------------------- GUI ----------------------------------------------------

# Create the Tkinter window and run the application
Home_Page = Tk()
Home_Page.title("Home_Page")
Home_Page.geometry('1366x768')
Home_Page.iconbitmap('')
Home_Page.resizable(False, False)

def Avian():
    Home_Page.destroy()
    import Avian

def Floran():
    Home_Page.destroy()
    import Floran  

def Germination():
    Home_Page.destroy()
    import Germination 

def Migration():
    Home_Page.destroy()
    import Migration     

cd_bg_image = ImageTk.PhotoImage(file='images//Home.png')
cd_bg_label = Label(Home_Page, image=cd_bg_image)
cd_bg_label.place(x=0, y=0)

Button(Home_Page, text='Species Search', font=('Open Sans', 20, 'bold'), fg='black', bg='gray', cursor='hand2',
        bd=0, width=15, height=1, command=Avian).place(x=900,y=500)

Button(Home_Page, text='Migration', font=('Open Sans', 20, 'bold'), fg='black', bg='gray', cursor='hand2',
        bd=0, width=15, height=1, command=Migration).place(x=900,y=350)

Button(Home_Page, text='Species Search', font=('Open Sans', 20, 'bold'), fg='black', bg='gray', cursor='hand2',
        bd=0, width=15, height=1, command=Floran).place(x=200,y=500)

Button(Home_Page, text='Germination', font=('Open Sans', 20, 'bold'), fg='black', bg='gray', cursor='hand2',
        bd=0, width=15, height=1, command=Germination).place(x=200,y=350)

Home_Page.mainloop()